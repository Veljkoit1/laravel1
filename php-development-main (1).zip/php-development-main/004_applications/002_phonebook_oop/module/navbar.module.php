<nav class="navigation">
    <ul>
        <li><a href="index"> <?= Language::get("menu", "home"); ?> </a></li>
        <li><a href="add"> <?= Language::get("menu", "add"); ?> </a></li>
        <li><a href="update"> <?= Language::get("menu", "update"); ?> </a></li>
        <li><a href="delete"> <?= Language::get("menu", "delete"); ?> </a></li>
    </ul>
</nav>