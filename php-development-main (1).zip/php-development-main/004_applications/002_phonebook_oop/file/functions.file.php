{
    "functions": [
        "test",
        "test2",
        "validate_name",
        "validate_email",
        "validate_pass",
        "register",
        "login",
        "edit_profile",
        "validate_phone",
        "check_pass_in_db",
        "change_password",
        "activate_user",
        "forgotten_password",
        "reset_forgotten_password"
    ]
}