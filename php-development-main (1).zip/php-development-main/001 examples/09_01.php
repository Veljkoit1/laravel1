<?php

@$some_variable = $_GET['some_parameter'];
echo $some_variable;