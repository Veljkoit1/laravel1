<?php

class MyClass { } 

$a = new MyClass(); 
$b = new MyClass(); 
var_dump($a===$b); 