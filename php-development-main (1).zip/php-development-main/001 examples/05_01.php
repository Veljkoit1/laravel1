<?php

class Constant{
    const PI = 3.14;
}

echo Constant::PI;